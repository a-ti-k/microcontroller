//Connect LCD module

sbit LCD_RS at RC0_bit;
sbit LCD_EN at RC1_bit;
sbit LCD_D4 at RC2_bit;
sbit LCD_D5 at RC3_bit;
sbit LCD_D6 at RC4_bit;
sbit LCD_D7 at RC5_bit;

//LCD Direction set
sbit LCD_RS_Direction at TRISC0_bit;
sbit LCD_EN_Direction at TRISC1_bit;
sbit LCD_D4_Direction at TRISC2_bit;
sbit LCD_D5_Direction at TRISC3_bit;
sbit LCD_D6_Direction at TRISC4_bit;
sbit LCD_D7_Direction at TRISC5_bit;


char te[] ="PABNA,PUST";
char text[] ="PUST,,ICE";


void main() {
          int i ,j;
         Adcon1 = 0x06;  //convert digital pin or disable analog pin
         Cmcon = 0x07;  //convert digital pin or disable comparator pin
         LCD_Init();
         LCD_cmd(_LCD_CLEAR);
         lcd_cmd(_LCD_cursor_off);
         lcd_out(1,1,te);
         lcd_out(2,1,text);
        while(1)
        {
          for(i=0;i<10;i++){
         lcd_cmd(_lcd_shift_left);
         delay_ms(500);}
          for(i=0;i<10;i++){
         lcd_cmd(_lcd_shift_right);
         delay_ms(500);    }
        }


}