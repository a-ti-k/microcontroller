
//function for 0 degree
void rotation_0_degree()
{
    int i;
    for(i=0;i<50;i++)
    {
      portb.f1=1;
      delay_us(800);
      portb.f1=0;
      delay_us(19200);
    }

}
 //function for 90 degree
void rotation_90_degree()
{
    int i;
    for(i=0;i<50;i++)
    {
      portb.f1=1;
      delay_us(1500);
      portb.f1=0;
      delay_us(18500);
    }
}

 //function for 180 degree
void rotation_180_degree()
{
    int i;
    for(i=0;i<50;i++)
    {
      portb.f1=1;
      delay_us(2200);
      portb.f1=0;
      delay_us(17800);
    }

}


void main() {

      while(1){
      TRISB = 0x00;
      rotation_0_degree();
      delay_ms(2000);
      rotation_90_degree();
      delay_ms(2000);
      rotation_180_degree();
      delay_ms(2000);
              }
      


  }