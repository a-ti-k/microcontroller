char string[4];

  void main() {
            int ADC_value;
            UART1_Init(9600);
            ADC_Init();
            while(1)
            {

             //Read ADC value from port
             ADC_value = ADC_Read(1);
             //Convert ADC value int to string
             IntToStr(ADC_value,string);
             //Print for this value
             UART1_Write_Text("Analog value   = ");
             UART1_Write_Text(string);
             UART1_Write(13);
             //clear this string
             strcpy(string,"");
             delay_ms(1000);
            
            
            
            
            
            }


}