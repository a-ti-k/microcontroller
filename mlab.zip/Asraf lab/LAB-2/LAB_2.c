 // it's for common cathode and decimal value for
 
 int array[]={63,6,91,79,102,109,125,7,127,111,63};
void main() {
           int i;
           TRISB = 0x00; //PORTB as a output
           PORTB = 0x00; //  initialize portb off condition
          for (i=0;;++i)
          {
           portb = array[i];
           delay_ms(1000);
           if(i==10){i=0;}

          }

}