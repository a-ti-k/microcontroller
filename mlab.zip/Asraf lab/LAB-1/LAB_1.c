void main() {
       TRISB = 0x00; //PORTB as a output
       PORTB = 0x00; //  initialize portb off condition

       while(1)
       {
         portb.f0 = 0xff;
         delay_ms(200);
         portb.f0 = 0x00;
         delay_ms(200);

       }
       


}