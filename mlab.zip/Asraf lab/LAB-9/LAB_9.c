//Connect LCD module

sbit LCD_RS at RC0_bit;
sbit LCD_EN at RC1_bit;
sbit LCD_D4 at RC2_bit;
sbit LCD_D5 at RC3_bit;
sbit LCD_D6 at RC4_bit;
sbit LCD_D7 at RC5_bit;

//LCD Direction set
sbit LCD_RS_Direction at TRISC0_bit;
sbit LCD_EN_Direction at TRISC1_bit;
sbit LCD_D4_Direction at TRISC2_bit;
sbit LCD_D5_Direction at TRISC3_bit;
sbit LCD_D6_Direction at TRISC4_bit;
sbit LCD_D7_Direction at TRISC5_bit;

char display[16]="";
void main() {
          int inputvalue;
          float result,temp;
          TRISA=0xff; //set as input
          LCD_Init();
          LCD_cmd(_LCD_CLEAR);
          lcd_cmd(_LCD_cursor_off);
          while(1){
          inputvalue = ADC_read(0); //A pin A0 point for read(0);
          result = inputvalue*4.88;
          temp = result/10;
          //result = inputvalue/2.0;
          //temp = result;
          floattostr(temp,display);
          lcd_out(1,1,"Temp = ");
          lcd_out_cp(display);
          lcd_chr(1,15,223);
          lcd_out_cp("C"); }
         



}