void MS_delay(int time)
 {    
 int i,j;
 for(i=0;i<time;i++)
  for(j=0;j<20;j++) ;
 }

void main() {

     TRISC = 0x00; //set as output
     TRISD = 0x00; //set as ouput;
     
     while(1)
     {
            portd = 0b10000000;    //portd switching for use led condition
            portc = 0b00000000;    //portc column wise led on and off condition for character
            MS_delay(10);
            portd = 0b01000000;
            portc = 0b11111111;
            MS_delay(10);
            portd = 0b00100000;
            portc = 0b11111111;
            MS_delay(10);
            portd = 0b00010000;
            portc = 0b11011000;
            MS_delay(10);
            portd = 0b00001000;
            portc = 0b11011000;
            MS_delay(10);
            portd = 0b00000100;
            portc = 0b11011000;
            MS_delay(10);
            portd = 0b00000010;
            portc = 0b11000000;
            MS_delay(10);
            portd = 0b00000001;
            portc = 0b00000000;
            MS_delay(10);

     
     
     }



}