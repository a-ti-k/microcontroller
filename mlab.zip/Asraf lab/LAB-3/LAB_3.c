
// it's for common cathode and decimal value for

int array[]={63,6,91,79,102,109,125,7,127,111};
void main() {
           int i=0;
           TRISB = 0x00; //PORTB as a output
           TRISC =0xff; //PORTC as a input
           PORTB = 0x00; //  initialize portb off condition
           while(1)
           {
            portb = array[i];
            delay_ms(10);
            if(portc.f1 == 0){
              delay_ms(300);
              if(i<9)
                {i++;}
              else
                {i=0;}       }
                
            if(portc.f0 == 0 ){ 
              delay_ms(300);
              if(i>0)
               {i--;}
              else
               {i=0;}   }
               
           
           }

}